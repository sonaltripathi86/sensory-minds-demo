import React, {Component} from 'react';
import logo from './logo.svg';
import './App.css';
import moment from 'moment';
import Channels from './components/Channels';
import ProgramsList from './components/ProgramsList';
import axios from 'axios';
import {SCALE, MINS_IN_AN_HOUR, TIME_ACCURACY} from './constants';



const mins_in_hour = 60;
//let channels = [];
class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      currentTime: moment().seconds(0).format(),
      channels : []
    };
    this.moveToCurrentPosition = this.moveToCurrentPosition.bind(this);
  }

  componentDidMount() {
    console.log("currentTime in app", this.state.currentTime, moment(this.state.currentTime));
    axios.get('../data/channels.json')
      .then(res => {
        const channels = res.data.result.channels;
        this.setState({
          channels 
      }); 
      })
    this.moveToCurrentPosition();
     // console.log("moment", moment(), new Date());

    this.isTimerStopped = false;
    this.timer = this.setTimer();
    
  }

  componentWillUnmount() {
    this.isTimerStopped = true;
    clearTimeout(this.timer);
  }

  setTimer() {
    return setTimeout(() => {
      if (this.isTimerStopped) {
        return;
      }

      this.setState({currentTime: moment().seconds(0).format()});
      this.timer = this.setTimer();
    }, TIME_ACCURACY);
  }

  getCurrentPosition() {
    
    const {currentTime} = this.state;
    const currentTimeMoment = moment(currentTime);
    //console.log("time********", currentTime, currentTimeMoment.hours(), currentTimeMoment.minutes() );
    return  (currentTimeMoment.hours() * MINS_IN_AN_HOUR + currentTimeMoment.minutes()) * SCALE;
  }

  moveToCurrentPosition() {
    const currentPosition = this.getCurrentPosition();
    console.log("currentPosition********", currentPosition);
    document.getElementById('timetable__scrollable').scrollLeft = currentPosition - window.innerWidth / 2;
  }
  render(){
    const {currentTime} = this.state;
    const currentPosition = this.getCurrentPosition();
    
    return(
      <div className = "App">
        <div className="App-main">
          <p>EPG - TV Shows</p>
        </div>
        <div id = "timetable__scrollable" className = "timetable__scrollable">

            <Channels
              channels = {this.state.channels}
            />
            <ProgramsList 
            channels = {this.state.channels}
            currentTime={currentTime}
            currentPosition={currentPosition}
             />
        </div>
        
      </div>
    )
  }
  
}

export default App;

import React, {Component} from 'react';
import Programs from './Programs';
import EPGNavContainer from './EPGNavContainer';
import {SCALE, MINUTES_IN_A_DAY} from '../constants';

const heightAboveTimetableBody = 113;
const height = window.innerHeight -heightAboveTimetableBody;
const displayStyle = {
    
    
  };
class ProgramsList extends React.Component {

    getContainerStyles() {
        console.log("height", height);
        const width = MINUTES_IN_A_DAY * SCALE;
    
        return {width};
      }

    render() {
        //console.log("progList dimension*******", document.body.clientWidth, window.innerWidth);
        const {channels, currentTime, currentPosition} = this.props;
        const containerStyles = this.getContainerStyles();
        const channelElements = channels.map(channel => {
            return <Programs currentTime={currentTime} channel={channel} key={channel.groupID}/>
          });
        return(
            
                <div className = "programsList" style={containerStyles}>
                <div className = "timetable__header">
                    <EPGNavContainer />
                </div>
                <div className = "timetable__body" style = {displayStyle}>
               
                    {channelElements}
                </div>
                <div className="timetable__current" style={{left: currentPosition}}> </div>
                </div>
            
        );
    }
}

export default ProgramsList;
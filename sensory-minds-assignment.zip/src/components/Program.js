import React, {Component} from 'react';
import moment from 'moment';
import {SCALE, MINS_IN_AN_HOUR, MILLISECONDS_IN_A_SECOND} from '../constants';

class Program extends React.Component {

    getProgramStyles() {
        const {program} = this.props;
        const start = moment(program.start);
        const end = moment(program.stop);
        const durationInSeconds = end.diff(start) / MILLISECONDS_IN_A_SECOND;
        
        const width = Math.floor(durationInSeconds * SCALE / MINS_IN_AN_HOUR);
        const left = ((start.hours() * MINS_IN_AN_HOUR + start.minutes()) * SCALE);
        //console.log("dimensions", durationInSeconds, width, left);
        return {
          left,
          width,
        };
      }
    

    render() {
    const {
        program,
        isActive,
        isVisible
        } = this.props;
    const title = program.title;
    const programStyle = this.getProgramStyles();
    //const programClass = this.getProgramClass();

    const startTime = moment(program.start).format('HH:mm');
    const endTime = moment(program.stop).format('HH:mm');

    return (
      <div className = {isActive ?  "timetable__body-cell_now":"timetable__body-cell"} style={programStyle} >
        <div className="timetable__broadcast">
          <div className="timetable__broadcast-name">{title}</div>
          <div className="timetable__broadcast-time">{startTime} - {endTime}</div>
        </div>
      </div>
    );
    }
}

export default Program;
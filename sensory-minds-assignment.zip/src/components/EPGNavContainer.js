import React, {Component} from 'react';
import {SCALE, MINS_IN_AN_HOUR, HOURS_IN_A_DAY} from '../constants';

const liStyle = {
    "marginLeft": "0px",
    "width": "160px",
    "display" : "inline",
    "float" : "left"
  };
let timeIntervalArray = [];
class EPGNavContainer extends React.Component {
    constructor(props){
        super(props);

        this.state = {
            scrolled :false
        }

    }

    componentDidMount() {
        
        window.addEventListener("scroll", () =>{
            const isTop = window.scrollY < 50;
            if (isTop !== true) {
                this.setState({
                    scrolled : true
                })
            }
            else {
                this.setState({
                    scrolled : false
                })
            }
        })
    }

    componentWillUnmount() {
        window.removeEventListener("scroll");
    }

    

    render() {
        const hours = new Array(HOURS_IN_A_DAY).fill(null).map((item, index) => index);
        const width = MINS_IN_AN_HOUR * SCALE;
        const cellStyles = {width};
        const hoursElements = hours.map(item => {
        return <span className="timetable__header-cell" style={cellStyles} key={item}>{item}:00</span>
        });
        return(
            <div className = {this.state.scrolled ? "EPGNAVContainer scrolled" : "EPGNAVContainer"}>
            
            {hoursElements}
              
                

            </div>
        )
    }
}

export default EPGNavContainer;

import React, {Component} from 'react';
import axios from 'axios';
import moment from 'moment';
import Program from './Program';
import VisibilitySensor from "react-visibility-sensor";



let shows = [];
 
class Programs extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            programs : []
        }
    }
    componentDidMount() {
            axios.get('../data/3.json')
            .then(res => {
                //const progs = res.data.result;
                let progList = this.getRequiredPrograms(res.data.result);
                //console.log("Programs",  programs);
                this.setState({
                    programs : progList
                })
            })
        
    }
    
    getRequiredPrograms(programs) {
        const {
            channel
        } = this.props
        let requiredPrograms = [];
         programs.map((requiredProgram) => {
            //const isActive = this.isProgramActive(program);
            if(requiredProgram.channelID === channel.groupID) {
                requiredPrograms.push(requiredProgram)
            }
            
    })
        return requiredPrograms;
    }

    isProgramActive(program) {
        const {currentTime} = this.props;
        const start = moment(program.start);
        const end = moment(program.stop);
        const current = moment(currentTime);
        //console.log("active programs", start, end, current );
        return current.isBetween(start, end, null, '[)');
      }

    onChange(isVisible) {

    }
    loadPrograms() {
        const {
            channel,
            isVisible
        } = this.props
        const {
            programs
        } = this.state;
        
        return programs.map((program, index) => {
            
                const isActive = this.isProgramActive(program);
                 //console.log("isVisible", isVisible);
                 
                return   <Program program={program} isActive={isActive} key={index} /> 
                    
        })
        
    }

    render() {
        shows = this.loadPrograms() ;
        return(
            
                <div className = "programRow" >{shows}</div>
           
        );
    }
}

export default Programs;
import React, {Component} from 'react';
import axios from 'axios';
import VisibilitySensor from "react-visibility-sensor";


let channelDetails = [];
const imageStyle = {
    "max-width": "100%",
    "max-height" : "100%"
  };
class Channels extends React.Component {
   
    constructor(props){
        super(props);

        this.state = {
            scrolled :false
        }

    }

    componentDidMount() {
        
        window.addEventListener("scroll", () =>{
            const isScrolled = window.scrollX > 20;
            if (isScrolled == true) {
                this.setState({
                    scrolled : true
                })
            }
            else {
                this.setState({
                    scrolled : false
                })
            }
        })
    }

    componentWillUnmount() {
        window.removeEventListener("scroll");
    }

    
    loadChannels() {
        const {channels} = this.props;
        channelDetails = channels.map( channelData => {
            let logo = `https://cdn.hd-plus.de/senderlogos/bright-cropped/${channelData.groupID}.png`;
            return  <VisibilitySensor key={channelData} >
                    {({ isVisible }) => {
                    return <div className = "channellogoWrapper" >
                                    <div className = "channelLogo" key = {channelData.groupID} >
                                       {isVisible ? <img src = {logo} style = {imageStyle}></img> : <img src = "" style = {imageStyle}></img>}  
                                    </div>
                                    
                                </div>
                            }}
                    </VisibilitySensor>
                      
        })
    }

    render(){
        const {channels} = this.props;
        this.loadChannels();
        return(
                <div className = {this.state.scrolled ? "timetable__captions scrolled" : "timetable__captions"}>
                    {channelDetails}
                    
                </div>
        )
    }
} 

export default Channels;